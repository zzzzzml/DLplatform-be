# 执行推理代码
python ./code/src/test.py
