/bin/bash /app/init.sh
/bin/bash /app/train.sh
/bin/bash /app/test.sh