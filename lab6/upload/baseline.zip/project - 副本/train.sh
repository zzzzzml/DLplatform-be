# 执行训练代码
# 进行特征工程
python ./code/src/featurework.py
# 进行模型训练
python ./code/src/train.py
